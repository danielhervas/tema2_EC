

let numero = 0;

alert ("esto es un ejemplo");
console.log("esto es un ejemplo en la consola");